# Music Player in JavaScript

In this exercise you are going to build a music player. There exists a repo containing all the information and assets you need: [Exercise JS Audio](https://github.com/Lexicon-Frontend-React-2023-2024/exercise-javascript-audio)

Go there, fork it, clone it down to your computer and get creative!