# Uppgift JS - Sirius Minishop

Denna uppgift ligger uppe på github. Länken har ni här: [Sirius Minishop](https://github.com/Lexicon-Frontend-React-2023-2024/exercise-sirius-minishop)

Uppgiften går ut på att leta reda på saker i DOM, ändra och skapa innehåll samt lyssna på event. Allt är beskrivet i README-filen som finn i repot.