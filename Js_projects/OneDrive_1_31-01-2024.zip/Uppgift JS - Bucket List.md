# Bucket List

In this assignment you are going to create your bucket list but in a different way than you might be used it. It's _**forbidden**_ in this assignment to add elements, content, styling or anything else, inside your HTML document or CSS files. All of this will be handled through vanilla JavaScript.

Go to this link and download the repo: [Bucket List](https://github.com/Lexicon-Frontend-React-2023-2024/exercise-bucket-list)

The purpose of the assignment is to learn how we can create basic, and more advanced content, solely with JavaScript.
