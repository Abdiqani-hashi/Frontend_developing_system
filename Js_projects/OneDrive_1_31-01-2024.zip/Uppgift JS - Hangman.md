# Hangman in JavaScript

In this exercise you are going to build your own verision of hangman. It's uploaded to github on this repo: [Hangman JS](https://github.com/Lexicon-Frontend-React-2023-2024/exercise-javascript-hangman).

Go to that link, fork the repo and clone it down to your computer and start cracking!